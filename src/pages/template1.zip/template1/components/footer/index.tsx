export function Footer(){
    return(
        <>
            <div className="h-40 w-full flex items-center justify-center bg-[#faf0e4]">
                <h3>Feito com carinho por Mpk & Zz</h3>
            </div>
        </>
    )
}